package com.Mugu.SpringMvc.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.Mugu.SpringMvc.model.Product;

@Repository
public interface ProductRepository extends JpaRepository<Product, Integer> {

}