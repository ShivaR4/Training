function validateform() {
    var name = document.myform.name.value;
    var password = document.myform.password.value;
    var firstpassword = document.myform.pwd.value;
    var secondpassword = document.myform.C_pwd.value;
    var age = document.myform.age.value;

    if (name == null || name == "" || number(name.length())<25) {
        window.alert("Name can't be less than 25 characters");
        return false;
    }else{
        window.alert("OK")
        return true;
    }
/*
    if (password.length < 8) {
        alert("Password must be at least 6 characters long.");
        return false;
    }

    if (firstpassword !== secondpassword) {
        alert("password must be same!");
        return false;
    }

    if (age<18 || age>99){
        alert("Age must be in range of (18-99) ..!!")
    }
*/

}
