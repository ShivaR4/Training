document.getElementById("First").placeholder = "Type First Number here...";
document.getElementById("Second").placeholder = "Type Second Number here...";

const firstTextBox = document.getElementById('First');
const secondTextBox = document.getElementById('Second');
var flag;
function add() {
    let a = Number(firstTextBox.value)
    let b = Number(secondTextBox.value)
    var res = a + b;
    alert("Result : " + a + "+" + b + " = " + res)
}
function sub() {
    let a = Number(firstTextBox.value)
    let b = Number(secondTextBox.value)
    var res = a - b;
    alert("Result : " + a + "-" + b + " = " + res)
}
function mul() {
    let a = Number(firstTextBox.value)
    let b = Number(secondTextBox.value)
    var res = a * b;
    alert("Result : " + a + "x" + b + " = " + res)
}
function div() {
    let a = Number(firstTextBox.value)
    let b = Number(secondTextBox.value)
    var res = a / b;
    alert("Result : " + a + "/" + b + " = " + res)
}
function pow() {
    let a = Number(firstTextBox.value)
    let b = Number(secondTextBox.value)
    var res = a ** b;
    alert("Result : pow(" + a + "," + b + ") = " + res)
}
function fillFirst() {
    flag = 1;
}
function fillSecond() {
    flag = 2;
}
function enterdigit(a) {
    var digit;
    digit =a;
    if (flag == 1) {
        firstTextBox.value = firstTextBox.value + digit;
    } else if  (flag == 2) {
        secondTextBox.value =secondTextBox.value +  digit;
    } else{
        alert ( "You did'nt choose the test area in which you want to enter the value. Please Choose then try to enter the values..!!" )
    }
}
function clearAll() {
    if (flag == 1) {
        firstTextBox.value ='';
    } else if  (flag == 2) {
        secondTextBox.value ='';
    } else{
        alert ( "You did'nt choose the test area in which you want to clear. Please Choose then try to clear it...!!" )
    }
}