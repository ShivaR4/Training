
public class wrap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s ="20";
		System.out.println(s+s);
		//System.out.println(int(s) + int(s));
	}

}
