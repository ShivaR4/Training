
public class SumOfDigit {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num=123456;
		int temp=0,sum=0,digit=0;
		temp=num;
		while(temp>0) {
			digit=temp%10;
			sum+=digit;
			temp/=10;
		}
		System.out.println("Sum of all the digits of "+num+ " : "+sum);
	}

}
