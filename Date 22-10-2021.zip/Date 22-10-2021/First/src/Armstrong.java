
public class Armstrong {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num = 153;
		int temp,digit;
		int sum=0;
		temp=num;
		while(temp>0) {
			digit=temp%10;
			sum=sum+(digit*digit*digit);
			temp=temp/10;
		}
		if(sum==num) {
			System.out.println("The number "+num+" is armstrong.");
		}else {
			System.out.println("The number "+num+" is not armstrong.");
		}
	}

}
