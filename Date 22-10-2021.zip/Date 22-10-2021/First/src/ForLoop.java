
public class ForLoop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=1;
		for (a=1;a<=10;a++) {
			System.out.println(a);
		}
	}

}
