
public class Fact {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num=10,temp;
		long fact=1;
		temp=num;
		if (num==0) {
			System.out.println("The factorial of "+temp+" : "+fact);
		}else {
			while(num>0) {
				fact*=num;
				num--;	
			  }
			System.out.println("The factorial of "+temp+" : "+fact);
		}
	}

}
