
public class Greatest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=28;
		int b=56;
		int c=12;
		if (a>b) {
			if (a>c) {
				System.out.println("a "+a+" is greatest");
			}else {
				System.out.println("c "+c+" is greatest");
			}
		}else {
			if (b>c) {
				System.out.println("b "+b+" is greatest");
			}else {
				System.out.println("c "+c+" is greatest");
			}
		}
			
	}

}
