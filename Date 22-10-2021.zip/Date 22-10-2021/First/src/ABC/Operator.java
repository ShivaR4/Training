package ABC;

public class Operator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a;
		//System.out.println(a);
	}

}
