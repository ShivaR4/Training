package ABC;

public class Datatype {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String Name ="Priya";
		byte age= 21;
		short yob = 2000;
		char c = 'A';
		int pincode = 273014;
		float perc = 86.04f;
		long num = 123456789;
		double d = 888.88;
		boolean tf = true;
		System.out.println(Name);
		System.out.println(age);
		System.out.println(yob);
		System.out.println(c);
		System.out.println(pincode);
		System.out.println(perc);
		System.out.println(num);
		System.out.println(d);
		System.out.println(tf);
		
	}

}
