package ABC;

public class Ladderif {
	public static void main(String[] args) {
	String city = "Delhi";  
	if(city == "Meerut") {  
	System.out.println("city is meerut");  
	}else if (city == "Noida") {  
	System.out.println("city is noida");  
	}else if(city == "Agra") {  
	System.out.println("city is agra");  
	}else {  
	System.out.println("city is "+city);  
	}  
}
}

