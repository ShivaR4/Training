package ABC;

public class IfElse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=10,b=12;
		if(a>b) {
			System.out.println("a is greater than b "+a+">"+b);
		}else {
			System.out.println("b is greater than a "+b+">"+a);
		}
	}

}