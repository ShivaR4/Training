package ABC;

public class ForEach {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[] names = {"Java","C","C++","Python","JavaScript"};    
		System.out.println("Printing the content of the array names: ");    
		for(String n:names) {    
		System.out.println(n);    
		}    
	}

}
