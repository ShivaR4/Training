package ABC;

public class BreakStatement {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i =1;
		for(i=1;i<=10;i++) {
			System.out.println(i);
			if(i==6) {
				System.out.println("Break Statement");
				break;
			}
		}
	}

}
