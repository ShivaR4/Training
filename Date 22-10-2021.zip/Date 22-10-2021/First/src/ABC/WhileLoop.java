package ABC;

public class WhileLoop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i=10;
		while(i>0) {
			System.out.println(i);
			i=i-2;
		}
	}

}
