package ABC;

public class DoWhile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i=10;
		do {
			//Execute this block then check condition
			System.out.println(i);
			i++;
		}while(i>20);

	}

}
