package ABC;

public class Hello {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Hello World");
		int a= 0b1010;
		char s= ' ' ;
		System.out.println("a is"+s + a);
	}

}
