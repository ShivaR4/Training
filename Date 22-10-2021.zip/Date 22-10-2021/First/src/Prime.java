
public class Prime {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num = 19,f=0;
		for (int i = 2;i<=num/2;i++) {
			if(num%i==0) {
				System.out.println("Number "+num+" is not Prime.");
				f=1;
				break;
				}
			}
		if(f==0){
			System.out.println("Number "+num+" is Prime.");
			}
		}
	}

