
public class Cchar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char c1='A';
		System.out.println(c1+"\n"+(int)c1+"\t" + (char)97 +"\n"+ "It is Hexa decimal  " +0x61);
		System.out.println("\u0061" + "We should provide and 4 hexa decimal number");
	}

}
