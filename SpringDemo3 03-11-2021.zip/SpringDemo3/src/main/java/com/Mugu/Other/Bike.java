package com.Mugu.Other;

public class Bike {
	public void run() {
		System.out.println("Bike is running");
	}

	private String company;

	public Bike(String company) {
		this.company = company;
	}
	public void printing() {
		System.out.println("Bike is running from Spring COMPANY: " + company);
	}
}
