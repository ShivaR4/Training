package com.Mugdha.SpringMvc.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class HomeController {

	@GetMapping("/Wish")
	@ResponseBody
	public String Wish() {
		return "Happy Deepawali..!!";
	}

	@GetMapping("/Index")
	public String getIndexPage(){
		return "Index";
	}
	
	@GetMapping("/addProduct")
	public String getHomePage(){
		return "addProduct";
	}
	
	@GetMapping("/DisplayProducts")
	public String getDisplayPage(){
		return "DisplayProduct";
	}
	
	@GetMapping("/Contact")
	public String getContactPage(){
		return "Contact";
	}
	
	@GetMapping("/About")
	public String getAboutPage(){
		return "About";
	}
}
