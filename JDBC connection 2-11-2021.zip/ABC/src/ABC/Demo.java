package ABC;
import java.sql.SQLException;
import java.util.ArrayList;

 

public class Demo {

 

    MyConnection c = MyConnection.getConnection();
    public void StatementDemo1() {
        int id[]= {1,2,3};
        String Name[] = {"Mugdha","Rishtika","Priya"};
        String Email[] = {"sum@dd.gn", "nin@fb.bf","roh@weg.fdb"};
        String Pno[] = {"555655565","44444444","88888888"};
        try {
            c.stmt = c.con.createStatement();
            int status=0;
            for(int i = 0 ; i<id.length ; i++) {
                 status += c.stmt.executeUpdate("insert into emp(ID, Name, Email,PNumber) values("+id[i]+",'"+Name[i]+"','"+Email[i]+"','"+Pno[i]+"')");
            }
            System.out.println(status);
//            int Ustatus=c.stmt.executeUpdate("delete from emp where ID in (2,3,4)");
//            System.out.println(Ustatus);
        } catch (SQLException e) {
            System.out.println(e);
        }finally {
            try {
                c.stmt.close();
            } catch (SQLException e) {
                System.out.println(e);
            }
        }
    }
    
    public void StatementDemo2() {
        ArrayList<Integer> ID = new ArrayList<>();
        ArrayList<String> Name = new ArrayList<>();
        ArrayList<String> Email = new ArrayList<>();
        ArrayList<String> No = new ArrayList<>();
        try {
            c.stmt = c.con.createStatement();
            c.rset = c.stmt.executeQuery("select * from emp");
            while(c.rset.next()) {
//                System.out.println(c.rset.getInt(1));
//                System.out.println(c.rset.getString(2));
//                System.out.println(c.rset.getString(3));
//                System.out.println(c.rset.getString(4));
                
//                System.out.println(c.rset.getInt("ID")+" "+c.rset.getString("Name")+" "+c.rset.getString("PNumber")+" "+c.rset.getString("Email"));
                
                ID.add(c.rset.getInt("ID"));
                Name.add(c.rset.getString("Name"));
                No.add(c.rset.getString("PNumber"));
                Email.add(c.rset.getString("Email"));
            }
            //Printing the data
            for(int i=0;i<ID.size();i++) {
                System.out.println(ID.get(i) + " " +Name.get(i) + " " +Email.get(i) + " "  + No.get(i));
            }
            
        } catch (SQLException e) {
            System.out.println(e);
        }finally {
            try {
                c.stmt.close();
            } catch (SQLException e) {
                System.out.println(e);
            }
        }
    }
    
//    execute(); DDL
//    executeUpdate(); insert update delete
//    executeQuery();  Select
    public static void main(String[] args) {
        Demo d = new Demo();
        d.StatementDemo1();
        d.StatementDemo2();
        
    }

 

}