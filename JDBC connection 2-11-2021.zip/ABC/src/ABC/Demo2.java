package ABC;
import java.sql.SQLException;
import java.util.ArrayList;


public class Demo2 {
	
	    MyConnection c = MyConnection.getConnection();
	    public void StatementDemo1() {
	        int id[]= {2,3,4};
	        String Name[] = {"Sumit","Nitin","Rohit"};
	        String Email[] = {"sum@dd.gn", "nin@fb.bf","roh@weg.fdb"};
	        String Pno[] = {"555655565","44444444","88888888"};
	        try {
	            c.stmt = c.con.createStatement();
	            int status=0;
	            for(int i = 0 ; i<id.length ; i++) {
	                 status += c.stmt.executeUpdate("insert into emp1(ID, Name, Email,PNumber) values("+id[i]+",'"+Name[i]+"','"+Email[i]+"','"+Pno[i]+"')");
	            }
	            System.out.println(status);
//	            int Ustatus=c.stmt.executeUpdate("delete from emp1 where ID in (2,3,4)");
//	            System.out.println(Ustatus);
	        } catch (SQLException e) {
	            System.out.println(e);
	        }finally {
	            try {
	                c.stmt.close();
	            } catch (SQLException e) {
	                System.out.println(e);
	            }
	        }
	    }
	    
	    public void StatementDemo2() {
	        ArrayList<Integer> ID = new ArrayList<>();
	        ArrayList<String> Name = new ArrayList<>();
	        ArrayList<String> Email = new ArrayList<>();
	        ArrayList<String> No = new ArrayList<>();
	        try {
	            c.stmt = c.con.createStatement();
	            c.rset = c.stmt.executeQuery("select * from emp1");
	            while(c.rset.next()) {
//	                System.out.println(c.rset.getInt(1));
//	                System.out.println(c.rset.getString(2));
//	                System.out.println(c.rset.getString(3));
//	                System.out.println(c.rset.getString(4));
	                
//	                System.out.println(c.rset.getInt("ID")+" "+c.rset.getString("Name")+" "+c.rset.getString("PNumber")+" "+c.rset.getString("Email"));
	                
	                ID.add(c.rset.getInt("ID"));
	                Name.add(c.rset.getString("Name"));
	                No.add(c.rset.getString("PNumber"));
	                Email.add(c.rset.getString("Email"));
	            }
	            
	            for(int i=0;i<ID.size();i++) {
	                System.out.println(ID.get(i) + " " +Name.get(i) + " " +Email.get(i) + " "  + No.get(i));
	            }
	            
	        } catch (SQLException e) {
	            System.out.println(e);
	        }finally {
	            try {
	                c.stmt.close();
	            } catch (SQLException e) {
	                System.out.println(e);
	            }
	        }
	    }
	    
//	    execute(); DDL
//	    executeUpdate(); insert update delete
//	    executeQuery();  Select
	    
	    
	    public void PreparedStatementDemo1() {
	        try {
	        
	            c.pstm = c.con.prepareStatement("insert into emp1 values(?,?,?,?)");
	            c.pstm.setInt(1,6);
	            c.pstm.setString(2,"Nayan");
	            c.pstm.setString(3,"Nayan@asdc.asd");
	            c.pstm.setString(4,"887755446");
	            int status = c.pstm.executeUpdate();
	            System.out.println(status);
	        } catch (SQLException e) {
	            System.out.println(e);
	        }
	    }
	    
	    public void PreparedStatementDemo2() {
	        try {
	        
//	            c.pstm = c.con.prepareStatement("select * from emp1 where ID =?");
//	            c.pstm.setInt(1,6);
	            c.pstm = c.con.prepareStatement("select * from emp1");
	            c.rset = c.pstm.executeQuery();
	            while(c.rset.next()) {
	                System.out.println(c.rset.getInt("ID")+" "+c.rset.getString("Name")+" "+c.rset.getString("PNumber")+" "+c.rset.getString("Email"));
	            }
	        } catch (SQLException e) {
	            System.out.println(e);
	        }
	    }
	    
	    public void PreparedStatementDemo3() {
	        try {
	            c.pstm = c.con.prepareStatement("select * from emp1");
	            c.rset = c.pstm.executeQuery();
	            
	            c.rsmd = c.rset.getMetaData();
	            
	            int cout =c.rsmd.getColumnCount();
	            
	            System.out.println(cout);
	            for( int i = 1; i<=cout;i++) {
	                System.out.print(c.rsmd.getColumnName(i)+"   ");
	            }
	            System.out.println();
	            while(c.rset.next()) {
	                System.out.println(c.rset.getInt("ID")+" "+c.rset.getString("Name")+" "+c.rset.getString("Email")+" "+c.rset.getString("PNumber"));
	            }
	        } catch (SQLException e) {
	            System.out.println(e);
	        }
	    }
	    
	    
	    public static void main(String[] args) {
	        Demo2 d = new Demo2();
//	        d.StatementDemo1();
//	        d.StatementDemo2();
	      //  d.PreparedStatementDemo1();
	        d.PreparedStatementDemo2();
	        d.PreparedStatementDemo3();
	    }

	 

	}

