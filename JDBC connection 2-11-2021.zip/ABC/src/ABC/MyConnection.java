package ABC;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

 


public final class MyConnection {
    
    private static MyConnection myConnection = null;
    
    public Connection con;
    public Statement stmt;
    public PreparedStatement pstm;
    public ResultSet rset;
    public ResultSetMetaData rsmd;
    
    
    private MyConnection() {
        
        try {
            
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = java.sql.DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/minipro", "MugdhaSrivastava", "Mugu@Sriva");
//            System.out.println("Done");
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println(e);
        }
        
        
    }
    
    
    public static MyConnection getConnection() {
        if (myConnection == null) {
            myConnection = new MyConnection();
        }
        return myConnection;
    }
    
    public void close() {
         myConnection = null;
         try {
            con.close();
        } catch (SQLException e) {
            System.out.println(e);
        }
    }
    

 

}