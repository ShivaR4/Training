package Batch89;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class CollectionArrayList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<String> lst = new ArrayList();
		lst.add("Mugdha");
		lst.add("Priya");
		lst.add("Rishtika");
		
		Iterator itr=lst.iterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
	}

}
