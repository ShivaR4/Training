package Batch89;
public class Parent{
	final static int A=10;
	void run() {
		System.out.println("Run in Parent");
	}	
	/*public static void main(String[] args) {
		Parent p = new Parent();
		System.out.println(p.A);
		p.A=12;
		System.out.println(p.A); 
	} */
}
