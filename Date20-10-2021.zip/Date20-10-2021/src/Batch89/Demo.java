package Batch89;

public class Demo implements DemoInterface {
	int A=1;
	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println("Using the interface in demo class with run");
	}

	@Override
	public void sleep() {
		// TODO Auto-generated method stub
		System.out.println("Using the interface in demo class with sleep");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Demo d= new Demo();
		d.run();
		d.sleep();
		System.out.println(d.A);
	}

}
