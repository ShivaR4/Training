/**
 * 
 */
package Batch89;

/**
 * @author mugdha_srivastava
 *
 */
public interface DemoInterface {
final int A=10;
void run();
void sleep();
}
