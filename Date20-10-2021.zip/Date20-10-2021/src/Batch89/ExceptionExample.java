package Batch89;

public class ExceptionExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			System.out.println("Using try catch for Exception");
			int num=100;
			System.out.println(num);
			System.out.println(num/0);
			
		} catch (ArithmeticException e) {
				// TODO: handle exception
				System.out.println(e);
		}try {
			String s = null;
			System.out.println(s.length());
		
		}catch (NullPointerException e) {
			// TODO: handle exception
			System.out.println(e);
		
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}
		System.out.println("Still Running...");
	}

}
