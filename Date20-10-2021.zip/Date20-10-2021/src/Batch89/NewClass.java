package Batch89;

public class NewClass extends Parent{
	int A=12;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		NewClass n = new NewClass();
		System.out.println(n.A);
		n.run();
		//n.A=12;
		NewClass n1 = new NewClass();
		System.out.println(n1.A);
		n1.run();
	}

}
