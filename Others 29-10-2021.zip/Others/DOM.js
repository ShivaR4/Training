const body= document.getElementById("body")
const heading = document.createElement("h1")
heading.innerHTML="Hello , Mugdha Srivastava"
body.appendChild(heading)
////Heading done <h1> hdshdbsjfhdhcnduh</h1>
const table = document.createElement("table")
table.setAttribute("border", "1px");
table.setAttribute("width", "500px");
//table
const Row1 = document.createElement('tr')
table.appendChild(Row1)
//first row
const head1 = document.createElement("th")
head1.innerHTML="Name"
const head2 = document.createElement("th")
head2.innerHTML="Age"
const head3 = document.createElement("th")
head3.innerHTML="Address"
Row1.appendChild(head1)
Row1.appendChild(head2)
Row1.appendChild(head3)
//Created three table heading
const Row2 = document.createElement('tr')
const data1=document.createElement("td")
data1.innerHTML="Mugdha"
const data2=document.createElement("td")
data2.innerHTML="21"
const data3=document.createElement("td")
data3.innerHTML="Gorakhpur"

const Row3 = document.createElement('tr')
const data4=document.createElement("td")
data4.innerHTML="Priya"
const data5=document.createElement("td")
data5.innerHTML="21"
const data6=document.createElement("td")
data6.innerHTML="GKP"

Row2.appendChild(data1)
Row2.appendChild(data2)
Row2.appendChild(data3)

Row3.appendChild(data4)
Row3.appendChild(data5)
Row3.appendChild(data6)
// Created data for table
table.appendChild(Row2)
table.appendChild(Row3)
//Appending rows in table
body.appendChild(table)
