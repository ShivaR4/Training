
public class Operations {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(-5 + (8 * 6));//43
		System.out.println((55+9) % 9);//1
		System.out.println(20 + -3*5 / 8);//19
		System.out.println(5 + ((15 / 3) * 2 )-( 8 % 3));//13
		
	}

}
