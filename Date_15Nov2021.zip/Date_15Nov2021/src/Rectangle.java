import java.util.Scanner;

public class Rectangle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		double l= sc.nextFloat();
		double w= sc.nextFloat();
		double peri, area;
		peri=2*(l+w);
		area=l*w;
		System.out.println("Perimeter is : "+peri);
		System.out.println("Area is :"+area);
	}

}
