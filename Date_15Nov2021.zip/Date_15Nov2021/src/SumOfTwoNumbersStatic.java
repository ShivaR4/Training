
public class SumOfTwoNumbersStatic {

	public static void main(String[] args) {
		// TODO Auto-generated method stub;
		int num1,num2;
		num1=74;
		num2=36;
		System.out.println(num1+num2);
	}

}
