
public class DivisionOfTwoNumbersStatic {

	public static void main(String[] args) {
		// TODO Auto-generated method stub;
		int num1,num2;
		num1=50;
		num2=3;
		System.out.println(num1/num2);
	}

}
