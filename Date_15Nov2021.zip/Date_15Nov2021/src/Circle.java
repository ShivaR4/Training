import java.util.Scanner;

public class Circle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		double r= sc.nextFloat();
		double peri, area;
		peri=2*3.14159265359*r;
		area=3.14159265359*r*r;
		System.out.println("Perimeter is : "+peri);
		System.out.println("Area is :"+area);
	}

}
