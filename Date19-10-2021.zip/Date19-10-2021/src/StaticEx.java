//Java Program to demonstrate the use of static variable
class Student{
 int rollno;//instance variable
 String name;
 static String college ="Dr. A.P.J. Abdul Kalam Technical University";//static variable
 //constructor
 Student(int r,String n){
 rollno = r;
 name = n;
 }
 //method to display the values
 void display (){
	 System.out.println("rollno : "+rollno+", Name : "+name+", University : "+college);}
}

//Test class to show the values of static variable
public class StaticEx {
public static void main(String args[]){
Student s1 = new Student(20,"Mugdha");
Student s2 = new Student(24,"Rishtika");
s1.display();
s2.display();
}
}