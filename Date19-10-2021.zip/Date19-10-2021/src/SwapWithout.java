import java.util.Scanner;  
public class SwapWithout{ 
	int a, b;
	public void swapping(int a, int b) {
		this.a=a;
		this.b=b;
		this.a = this.a + this.b;  
		this.b = this.a - this.b;  
		this.a = this.a - this.b;  
		System.out.println("After swapping: a= "
		+ this.a + ", b= " + this.b);  
	}
public static void main(String args[])   
{  
SwapWithout sn = new SwapWithout();  
Scanner s = new Scanner(System.in);               
System.out.print("Enter the first number: ");  
sn.a = s.nextInt();  
System.out.print("Enter the second number: ");  
sn.b = s.nextInt();    
sn.swapping(sn.a, sn.b);
}  
}  