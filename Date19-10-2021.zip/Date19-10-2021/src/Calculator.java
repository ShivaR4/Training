import java.util.Scanner;
public class Calculator {
   public static void main(String args[]) {
      Scanner sc = new Scanner(System.in);
      
      System.out.println("Enter the 1st number : ");
      float a1 = sc.nextFloat();
      System.out.println("Enter the 2nd number : ");
      float b1 = sc.nextFloat();
      
      int flag=0;
     do{
      System.out.println("\n **********************************"+ "************* \n \n Please choose any option: ");
      System.out.println(" 1 for Addition \n 2 for Subtraction "+ "\n 3 for Multiplication \n 4 for Div \n 5 for quit");
      int op = sc.nextInt();     
      switch(op) {
         case 1 :
        	 System.out.println("Addition of two numbers: "+(a1+b1));
        	 break;
         case 2 :
        	 System.out.println("Subtraction of two numbers: "+(a1-b1));
        	 break;
         case 3 :
        	 System.out.println("Multiplication of two numbers: "+(a1*b1));
        	 break;
         case 4 :
        	 System.out.println("Division of two numbers: "+(a1/b1));
        	 break;
         case 5 :
             System.out.println("You choose to quit, bye bye ");
             flag=1;
             break;
         default :
        	 System.out.println("Invalid option");
        	 break;
      }
   } while(flag==0) ;
  }}