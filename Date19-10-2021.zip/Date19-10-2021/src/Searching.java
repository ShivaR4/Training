import java.util.Scanner;
public class Searching {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		  Scanner sc = new Scanner(System.in);
		  
	      System.out.println("Enter the size of the array : ");
	      int size = sc.nextInt();
	      
	      int arr[] = new int[size];
	      System.out.println("Enter "+size+" elements of  the array : \n");
	      
	      for (int i=0;i<size;i++) {
	    	  arr[i] = sc.nextInt();
	    		 }
	      System.out.println(" Your array is: ");
	      for (int j=0;j<size;j++) {
	    	 System.out.print(" "+arr[j] );
	    		 }
	      System.out.println("\n what do you want to search? ");
	      int key = sc.nextInt();
	      
	      int flag=0;
	      for (int i = 0; i < arr.length; i++) {
	          if (arr[i] == key) {
	             System.out.println("Element "+key+" @ index : "+i);
	             flag=1;
	          }}
	      
	      if(flag==0) {
	    	  System.out.println("Your entered element isn't exist in the array");
	      }
	}
}
