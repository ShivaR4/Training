class Demo {
	int a=10;
	 /*
	   final void run() {
	  
		System.out.println("Running");
	}
	*/
	}

class FinalDemo extends Demo{
	void run(){
		System.out.println("Run in class Demo");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FinalDemo d = new FinalDemo();
		System.out.println(d.a);
		d.run();	
	}
}
