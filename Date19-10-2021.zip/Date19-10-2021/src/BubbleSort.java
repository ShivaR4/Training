import java.util.Scanner;

public class BubbleSort {

	public static void main(String[] args) {
		
		  Scanner sc = new Scanner(System.in);
	      
	      System.out.println("Enter the size of the array : ");
	      int size = sc.nextInt();
	      
	      int arr[] = new int[size];
	      System.out.println("Enter "+size+" elements of  the array : \n");
	      
	      for (int i=0;i<size;i++) {
	    	  arr[i] = sc.nextInt();
	    		 }
	      System.out.println(" Before sorting : ");
	      for (int j=0;j<size;j++) {
	    	 System.out.print(" "+arr[j] );
	    		 }
	      System.out.println("\n \n **********************************");
	      System.out.println("\n Applying Bubble sorting...");
	      
	         for(int i=0; i < size; i++){  
	                 for(int j=1; j < (size-i); j++){  
	                          if(arr[j-1] > arr[j]){  
	                                 arr[j-1] = arr[j-1] + arr[j];  
	                                 arr[j] = arr[j-1] - arr[j];  
	                                 arr[j-1] = arr[j-1] - arr[j];
	                         }}}  
	         
	         System.out.println("\n **********************************");
	         System.out.println("\n After sorting : ");
		      for (int j=0;j<size;j++) {
		    	 System.out.print(" "+arr[j] );
		    		 }  
	         
	}

}
