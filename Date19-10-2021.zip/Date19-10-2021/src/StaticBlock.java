public class StaticBlock {
	//This block will execute before main
	static{
		System.out.println("static block is invoked");
		}  
	  public static void main(String args[]){  
	   System.out.println("Hello From MainFunction");  
	  }  
	}  
