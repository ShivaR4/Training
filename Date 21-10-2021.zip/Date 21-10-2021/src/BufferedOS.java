import java.io.*;  
public class BufferedOS {
	public static void main(String args[])throws Exception{    
	     FileOutputStream fout=new FileOutputStream("C:\\Users\\mugdha_srivastava\\Desktop\\OutputStream\\Buffer.txt");    
	     BufferedOutputStream bout=new BufferedOutputStream(fout);    
	     String s="I am Priya Srivastava. I have completed my B.Tech from Dr. A.P.J. Abdul Kalam Technical University.";    
	     byte b[]=s.getBytes();    
	     bout.write(b);    
	     bout.flush();    
	     bout.close();    
	     fout.close();    
	     System.out.println("success");    
	}    
}
