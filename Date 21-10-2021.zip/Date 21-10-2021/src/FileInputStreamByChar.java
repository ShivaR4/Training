import java.io.FileInputStream; 
public class FileInputStreamByChar {
	public static void main(String args[]){    
        try{    
          FileInputStream fin = new FileInputStream("C:\\Users\\mugdha_srivastava\\Desktop\\OutputStream\\FileInput.txt");    
      
          int i=fin.read();  
          System.out.print((char)i);    

          fin.close();    
        }catch(Exception e)
        	{System.out.println(e);}    
       }    
      }


     