
public class BufferedInput {

}
