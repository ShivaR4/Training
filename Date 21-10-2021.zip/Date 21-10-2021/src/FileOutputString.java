import java.io.FileOutputStream;  
public class FileOutputString {
	    public static void main(String args[]){    
	           try{    
	             FileOutputStream fout=new FileOutputStream("C:\\Users\\mugdha_srivastava\\Desktop\\OutputStream\\String.txt");    
	             String s="Hello, I am Mugdha Srivastava.";    
	             byte b[]=s.getBytes();//converting string into byte array    
	             fout.write(b);    
	             fout.close();    
	             System.out.println("success...");    
	            }catch(Exception e){System.out.println(e);}    
	      }    
}