import java.io.FileOutputStream;  
public class FileOutputStreamExample {  
    public static void main(String args[]){    
           try{    
             FileOutputStream fout=new FileOutputStream("C:\\Users\\mugdha_srivastava\\Desktop\\OutputStream\\New.txt");    
             fout.write(65);
             byte [] b= new byte[4];
             b[0]=66;
             b[1]=98;
             b[2]=68;
             b[3]=90;
             fout.write(b);
             fout.close();    
             System.out.println("success...");    
            }catch(Exception e){System.out.println(e);}    
      }    
}  