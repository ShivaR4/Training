package com.Mugu.Test;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

//import com.Mugu.Other.Bike;
//import com.Mugu.Other.Car;
import com.Mugu.Other.Engine;

@Configuration
@ComponentScan(basePackages = "com.Mugu")
public class SpringConfig {

	@Bean
	public Engine getEngine() {
		return new Engine("3000 CC");

		/*
		 * @Bean public Car getCar() { return new Car(); }
		 * 
		 * @Bean public Bike getBike() { return new Bike();
		 */
	}
}
