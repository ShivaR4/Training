package com.Mugu.Test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import com.Mugu.Other.Bike;
import com.Mugu.Other.Car;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext context = new AnnotationConfigApplicationContext(SpringConfig.class);
	
		Car c = context.getBean("car",Car.class);
		c.run();
		//c.printing();
		Bike b = (Bike) context.getBean("bike");
		b.run();
		//b.printing();
	}

}
