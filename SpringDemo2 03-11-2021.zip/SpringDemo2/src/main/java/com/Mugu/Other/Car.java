package com.Mugu.Other;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("car")
public class Car {
//dependency injection
	@Autowired
	private Engine engine;

	@Autowired
	private Tyre tyre;

	
	public void run() {
		System.out.println("Car is running");
		engine.display();
		System.out.println(tyre);
	}

}
