package com.Mugu.Other;

import org.springframework.stereotype.Component;

@Component
public class Tyre {

}