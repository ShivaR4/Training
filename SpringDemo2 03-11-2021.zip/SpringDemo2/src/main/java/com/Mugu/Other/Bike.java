package com.Mugu.Other;

import org.springframework.stereotype.Component;

@Component("bike")
public class Bike {
	public void run() {
		System.out.println("Bike is running");
	}

}
